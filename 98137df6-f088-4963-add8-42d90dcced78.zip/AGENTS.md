<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep restaurant information and ordering destinations in a shared browser-safe data module so all pages stay consistent.
- Use shared site chrome around the root Outlet and distinct content routes so navigation and page metadata remain reliable.
- Use original restaurant photos through asset pointers rather than embedding reference screenshots so the site remains usable and lightweight.
- Keep homepage ordering guidance in focused presentation components using shared restaurant data so conversion sections do not duplicate prices or ordering destinations.
- Keep homepage meal discovery as accessible collection tabs backed by shared menu data; category choices must not duplicate item prices or imply a cart exists on this site.
