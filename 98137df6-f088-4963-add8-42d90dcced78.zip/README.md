# copy of zay

I want you to recreate this same website but even more user-friendly, like Apple. Here is the link and attached screenshots "https://preview-1790262805371067554.vibepreview.app/" make sure it's user-friendly and optimized for mobile as well. i have attached the mobile version of it too

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/98137df6-f088-4963-add8-42d90dcced78).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
