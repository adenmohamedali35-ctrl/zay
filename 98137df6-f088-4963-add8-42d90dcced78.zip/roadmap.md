# Roadmap
- [x] Refine the homepage with Apple-like clarity, focused meal discovery, and clearer ordering sections.
- [x] Verify meal choices, ordering links, navigation, video controls, and phone layouts.
- [x] Adapt Zay Zaman’s visual presentation to Figaro’s inspiration while preserving its video and ordering flows.
- [x] Verify the refreshed pages, navigation, video playback, and phone layout.
- [x] Add premium ordering choices, a family-meal feature, and ordering questions.
- [x] Verify new links, expandable answers, and desktop/phone presentation.
- [x] Recreate the restaurant homepage with original food photography and clearer navigation.
- [x] Add usable menu, offers, story, and visit pages with working ordering links.
- [x] Verify ordering destinations, navigation, menu filtering, photo loading, and mobile layout.