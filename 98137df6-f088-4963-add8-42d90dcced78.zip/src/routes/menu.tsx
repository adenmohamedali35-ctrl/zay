import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { Search, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/restaurant';
import { categories, filterMenu, pageHead } from '@/lib/restaurant';
export const Route = createFileRoute('/menu')({ head: () => pageHead('Our menu', 'Explore Zay Zaman’s shawarma, family plates, pizza, manakeesh and sides, with prices and easy online ordering.'), component: MenuPage });
function MenuPage() {
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const items = filterMenu(category, query);
  return <main className="site-width menu-page"><div className="page-intro"><div className="eyebrow">Made fresh. Made for you.</div><h1 className="page-title">Find your favourite.</h1><p className="section-subtitle">From a quick wrap to a feast for the whole table.</p></div><div className="menu-toolbar"><div className="category-tabs" aria-label="Menu categories">{categories.map(c => <Button key={c} variant={category === c ? 'default' : 'ghost'} onClick={() => setCategory(c)} aria-pressed={category === c} className="shrink-0 text-xs">{c}</Button>)}</div><label className="search-field"><Search size={16}/><input aria-label="Search the menu" placeholder="Search the menu" value={query} onChange={e => setQuery(e.target.value)}/>{query && <Button variant="ghost" size="icon" className="h-6 w-6" aria-label="Clear search" onClick={() => setQuery('')}><X size={14}/></Button>}</label></div><div className="mb-5 text-xs text-muted-foreground" aria-live="polite">{items.length} dishes · Prices in CAD</div>{items.length > 0 ? <div className="product-grid">{items.map(item => <ProductCard key={item.name} item={item}/>)}</div> : <div className="empty-results"><h2>No dishes found.</h2><p className="mt-3 text-sm">Try another search or category.</p><Button className="mt-5" variant="outline" onClick={() => { setQuery(''); setCategory('All'); }}>Show all dishes</Button></div>}</main>;
}