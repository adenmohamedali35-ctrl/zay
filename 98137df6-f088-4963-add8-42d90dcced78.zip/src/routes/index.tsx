import { createFileRoute } from "@tanstack/react-router";
import { Link } from '@tanstack/react-router';
import { useRef, useState } from 'react';
import { ArrowRight, MapPin, Star, Pause, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { OrderButton, VisitSection, FinalCTA } from '@/components/restaurant';
import { restaurant, pageHead } from '@/lib/restaurant';
import hero from '@/assets/hero-food.jpg.asset.json';
import heroVideo from '@/assets/hero-video.mp4.asset.json';
import heroVideoWebm from '@/assets/hero-video.webm.asset.json';
import halalSeal from '@/assets/hero-halal-seal.png.asset.json';
import { MealDiscovery, FamilyFeature } from '@/components/home-conversion';
import { CategoryCircles, QualityPromo, ReviewsSection } from '@/components/home-inspired';
export const Route = createFileRoute("/")({
  head: () => pageHead('Middle Eastern food in Kitchener', 'Fresh shawarma, warm manakeesh and family plates. Discover Zay Zaman on Lancaster Street, serving Kitchener since 2015.'),
  component: Index,
});
function Index() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [paused, setPaused] = useState(false);
  const toggleVideo = async () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) { try { await video.play(); } catch { setPaused(true); } }
    else video.pause();
  };
  return (
    <main>
      <section className="hero">
        <video ref={videoRef} className="hero-video" poster={hero.url} autoPlay loop muted playsInline aria-hidden="true" tabIndex={-1} onPause={() => setPaused(true)} onPlay={() => setPaused(false)}>
          <source src={heroVideo.url} type="video/mp4"/>
          <source src={heroVideoWebm.url} type="video/webm"/>
        </video>
        <div className="site-width hero-content fade-in">
          <div className="eyebrow">Middle Eastern soul. Kitchener heart.</div>
          <h1>Authentic taste.<br/><em>The good old days.</em></h1>
          <p className="hero-description">Shawarma fresh off the spit. Manakeesh warm from the oven.<br/>The flavours you love, made with heart.</p>
          <div className="hero-buttons">
            <OrderButton label="Order online"/>
            <Button asChild variant="hero" size="lg"><Link to="/menu">Explore the menu<ArrowRight/></Link></Button>
          </div>
          <a className="hero-location" href={restaurant.directions} target="_blank" rel="noopener noreferrer"><MapPin size={16}/><span>309 Lancaster St W · Kitchener, Ontario</span></a>
        </div>
        <Button className="hero-video-control" variant="hero" size="icon" aria-label={paused ? 'Play background video' : 'Pause background video'} title={paused ? 'Play video' : 'Pause video'} onClick={toggleVideo}>{paused ? <Play/> : <Pause/>}</Button>
        <div className="site-width hero-trust">
          <div className="hero-halal">
            <img src={halalSeal.url} alt="100% halal seal" width="68" height="68"/>
            <div><strong>100% Halal</strong><p>Every order, every ingredient.</p></div>
          </div>
          <a className="hero-rating" href={restaurant.review} target="_blank" rel="noopener noreferrer" aria-label="4.8 out of 5 stars on Google from 1,283 reviews">
            <strong>4.8<Star aria-hidden="true" strokeWidth={1.5}/></strong><span>1,283 Google reviews</span>
          </a>
        </div>
      </section>
      <CategoryCircles/>
      <MealDiscovery/>
      <QualityPromo/>
      <FamilyFeature/>
      <ReviewsSection/>
      <VisitSection/>
      <FinalCTA/>
    </main>
  );
}
