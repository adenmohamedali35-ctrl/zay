import { createFileRoute } from '@tanstack/react-router';
import { StorySection, FinalCTA } from '@/components/restaurant';
import { pageHead } from '@/lib/restaurant';
export const Route = createFileRoute('/about')({ head: () => pageHead('Our story', 'Meet Zay Zaman, a neighbourhood favourite bringing traditional Middle Eastern flavours to Kitchener since 2015.'), component: AboutPage });
function AboutPage() { return <main><div className="site-width page-intro"><div className="eyebrow">Zay Zaman · Since 2015</div><h1 className="page-title">The good old days.<br/>Right here in Kitchener.</h1><p className="section-subtitle">Familiar flavours. Warm welcomes. Food worth coming back for.</p></div><StorySection/><FinalCTA/></main>; }