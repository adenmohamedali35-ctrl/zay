import { createFileRoute } from '@tanstack/react-router';
import { VisitSection } from '@/components/restaurant';
import { pageHead } from '@/lib/restaurant';
export const Route = createFileRoute('/contact')({ head: () => pageHead('Visit us', 'Find Zay Zaman at 309 Lancaster Street West in Kitchener. Check opening hours, call (519) 741-1110 or get directions.'), component: ContactPage });
function ContactPage() { return <main><div className="site-width page-intro"><div className="eyebrow">There’s a seat for you</div><h1 className="page-title">Come hungry.<br/>Leave happy.</h1><p className="section-subtitle">Find us on Lancaster Street, in the heart of Kitchener.</p></div><VisitSection/></main>; }