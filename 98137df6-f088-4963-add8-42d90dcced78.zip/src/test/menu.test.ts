import { describe, it, expect } from 'vitest';
import { filterMenu } from '@/lib/restaurant';
describe('Menu selection', () => {
  it('shows only wraps when Wraps is selected', () => {
    const result = filterMenu('Wraps', '');
    expect(result.length).toBe(4);
    expect(result.every(item => item.category === 'Wraps')).toBe(true);
  });
  it('combines a category with case-insensitive search', () => {
    expect(filterMenu('Family plates', 'SHAWARMA').map(item => item.name)).toEqual(['Shawarma Family Plate']);
  });
  it('returns no dishes for an unmatched search', () => {
    expect(filterMenu('All', 'not-a-dish')).toEqual([]);
  });
});