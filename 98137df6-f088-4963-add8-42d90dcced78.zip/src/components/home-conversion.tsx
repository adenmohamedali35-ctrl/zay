import { Link } from '@tanstack/react-router';
import { ArrowRight, ShoppingBag, Bike, Utensils, Check, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { OrderButton, ProductCard } from '@/components/restaurant';
import { favourites, restaurant, priceLabel } from '@/lib/restaurant';

export function MealDiscovery() {
  const collections = [
    { value: 'favourites', label: 'Favourites', items: favourites.filter(item => ['Shawarma Wrap', 'Shawarma Plate', 'On The Rox'].includes(item.name)) },
    { value: 'sharing', label: 'To share', items: favourites.filter(item => item.category === 'Family plates') },
    { value: 'vegetarian', label: 'Vegetarian', items: favourites.filter(item => item.name === 'Falafel Family Plate') },
  ];
  return <section className="section meal-discovery" id="favourites" aria-labelledby="meal-title"><div className="site-width">
    <div className="section-heading"><div><div className="eyebrow">Made fresh. Pick your favourite.</div><h2 id="meal-title">What are you craving?</h2><p className="section-subtitle">A wrap for you. A feast for everyone.</p></div><Button asChild variant="link" className="desktop-link"><Link to="/menu">See the full menu<ArrowRight/></Link></Button></div>
    <Tabs defaultValue="favourites"><TabsList className="meal-tabs" aria-label="Choose a meal collection">{collections.map(collection => <TabsTrigger key={collection.value} value={collection.value}>{collection.label}</TabsTrigger>)}</TabsList>
      {collections.map(collection => <TabsContent key={collection.value} value={collection.value}><div className="product-grid">{collection.items.map(item => <ProductCard key={item.name} item={item}/>)}</div></TabsContent>)}
    </Tabs><div className="meal-menu-link"><span>More shawarma, manakeesh, pizza & sides.</span><Button variant="link" asChild><Link to="/menu">Explore the menu<ArrowRight/></Link></Button></div>
  </div></section>;
}

export function OrderingChoices() {
  const choices = [
    { icon: ShoppingBag, title: 'Order pickup', text: 'Choose your meal online. Collect at 309 Lancaster Street West.', action: 'Start pickup order', href: restaurant.order },
    { icon: Bike, title: 'Delivery options', text: 'Check your address, times and fees with our ordering partner.', action: 'Check availability', href: restaurant.order },
    { icon: Utensils, title: 'Dine in', text: 'Join us on Lancaster for your favourites, straight from the kitchen.', action: 'Get directions', href: restaurant.directions },
  ];
  return <section className="ordering-section" aria-labelledby="ordering-title"><div className="site-width"><div className="ordering-heading"><div><div className="eyebrow">Good food. Your way.</div><h2 id="ordering-title">Here, there, or on the go.</h2></div></div><div className="ordering-grid">{choices.map(({ icon: Icon, ...choice }) => <article className="ordering-choice" key={choice.title}><Icon className="ordering-icon" strokeWidth={1.5}/><h3>{choice.title}</h3><p>{choice.text}</p><Button variant="link" asChild className="px-0 text-xs font-bold"><a href={choice.href} target="_blank" rel="noopener noreferrer">{choice.action}<ArrowRight/></a></Button></article>)}</div></div></section>;
}

export function FamilyFeature() {
  const family = favourites.find(item => item.name === 'Shawarma Family Plate');
  if (!family?.image) return null;
  return <section className="family-feature" aria-labelledby="family-title"><img className="family-feature-photo" src={family.image} alt="Shawarma family plate with four wraps, fries, garlic sauce and pickles" loading="lazy"/><div className="site-width family-feature-content"><div className="eyebrow">Less planning. More together.</div><h2 id="family-title">The whole table.<br/>One great order.</h2><p>Movie night. Family night. Just-because night.<br/>Make room for a meal everyone can share.</p><ul className="family-inclusions">{['Four shawarma wraps', 'Crispy fries & pickles', 'Signature garlic sauce'].map(label => <li key={label}><Check size={16}/>{label}</li>)}</ul><div className="family-feature-price"><strong>{priceLabel(family.price)}</strong><span>Shawarma Family Plate · CAD</span></div><div className="hero-buttons"><OrderButton label="Order a family feast"/><Button variant="inverse" size="lg" asChild><Link to="/menu">All family plates<ArrowRight/></Link></Button></div></div></section>;
}

export function OrderingQuestions() {
  return <section className="section questions-section" aria-labelledby="questions-title"><div className="site-width questions-grid"><div className="questions-intro"><div className="eyebrow">A few good answers</div><h2 id="questions-title">Before your<br/>first bite.</h2><p>Have something else in mind?<br/>We’re happy to help.</p><Button variant="link" asChild className="px-0 mt-5 text-xs font-bold"><a href={restaurant.phone}><Phone/>(519) 741-1110</a></Button></div><Accordion type="single" collapsible className="questions-list"><AccordionItem value="ordering"><AccordionTrigger>How do I place an order?</AccordionTrigger><AccordionContent>Order online for pickup through our ordering partner, or call us at (519) 741-1110. Collect your meal at 309 Lancaster St W in Kitchener.<Button variant="link" asChild className="flex w-fit px-0 mt-2 text-xs font-bold"><a href={restaurant.order} target="_blank" rel="noopener noreferrer">Start your order<ArrowRight/></a></Button></AccordionContent></AccordionItem><AccordionItem value="delivery"><AccordionTrigger>Can I have my food delivered?</AccordionTrigger><AccordionContent>Delivery options are available through our ordering partner. Check your address, available times and any fees there before placing your order.</AccordionContent></AccordionItem><AccordionItem value="vegetarian"><AccordionTrigger>Are there vegetarian options?</AccordionTrigger><AccordionContent>Yes. Try a falafel wrap, falafel plate or falafel family plate, along with options like hummus and za’atar manakeesh. For allergies or specific dietary needs, call us before ordering.</AccordionContent></AccordionItem><AccordionItem value="sharing"><AccordionTrigger>What should I order for the family?</AccordionTrigger><AccordionContent>Our Shawarma Family Plate includes four shawarma wraps, fries, garlic sauce and pickles. You can also choose a falafel family plate or a grill family plate from the menu.</AccordionContent></AccordionItem><AccordionItem value="allergies"><AccordionTrigger>Can I ask about ingredients or allergies?</AccordionTrigger><AccordionContent>Of course. Please call (519) 741-1110 before ordering so our team can discuss ingredients and preparation with you.</AccordionContent></AccordionItem></Accordion></div></section>;
}