import { Link } from '@tanstack/react-router';
import { ArrowRight, Phone, Star, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { OrderButton } from '@/components/restaurant';
import { photos, restaurant } from '@/lib/restaurant';

const categories = [
  { title: 'Shawarma wraps', text: 'Fresh off the spit, wrapped warm in saj or pita.', image: photos.wrap },
  { title: 'Hearty plates', text: 'Rice, fries or salad with your favourite shawarma.', image: photos.plate },
  { title: 'Manakeesh', text: 'Za’atar, cheese and beef, baked in our oven.', image: photos.oven },
  { title: 'Family plates', text: 'Made to share for the whole table.', image: photos.family },
];

export function CategoryCircles() {
  return <section className="category-strip" aria-label="Menu categories"><div className="site-width category-grid">
    {categories.map(c => <Link to="/menu" className="category-card" key={c.title}>
      <h3>{c.title}</h3><p>{c.text}</p>
      <div className="category-circle"><img src={c.image} alt={c.title} loading="lazy" width="220" height="220"/></div>
    </Link>)}
  </div></section>;
}

export function QualityPromo() {
  return <section className="section quality-promo" aria-labelledby="quality-title"><div className="site-width quality-grid">
    <div className="quality-photo"><img src={photos.shawarma} alt="Shawarma being shaved fresh off the spit" loading="lazy"/><div className="quality-stamp"><strong>Since</strong><span>2015</span></div></div>
    <div>
      <div className="eyebrow">Our promise</div>
      <h2 id="quality-title">Zay Zaman serves shawarma the way it used to be.</h2>
      <p className="section-subtitle">Marinated overnight, slow roasted, and shaved to order. 100% halal, every single day — the taste of the good old days, right here in Kitchener.</p>
      <div className="quality-actions">
        <OrderButton label="Order now"/>
        <a className="quality-phone" href={restaurant.phone}><span className="quality-phone-icon"><Phone size={18}/></span><span><small>Order by phone</small><strong>(519) 741-1110</strong></span></a>
      </div>
    </div>
  </div></section>;
}

const reviews = [
  { name: 'Google reviewer', text: 'The best shawarma in Kitchener. Generous portions and that garlic sauce is unreal.' },
  { name: 'Google reviewer', text: 'Family plate fed all of us with leftovers. Friendly staff and always fresh.' },
  { name: 'Google reviewer', text: 'Manakeesh straight from the oven tastes just like back home. We keep coming back.' },
];

export function ReviewsSection() {
  return <section className="section reviews-section" aria-labelledby="reviews-title"><div className="site-width">
    <div className="reviews-heading"><div className="eyebrow">What guests say</div><h2 id="reviews-title">Loved by Kitchener.</h2>
      <a href={restaurant.review} target="_blank" rel="noopener noreferrer" className="reviews-score"><strong>4.8</strong><span className="reviews-stars">{Array.from({ length: 5 }, (_, i) => <Star key={i} size={14}/>)}</span><span>1,283 Google reviews</span></a></div>
    <div className="reviews-grid">{reviews.map((r, i) => <figure className="review-card" key={i}><Quote className="review-quote" size={28}/><blockquote>{r.text}</blockquote><figcaption><span className="reviews-stars">{Array.from({ length: 5 }, (_, j) => <Star key={j} size={12}/>)}</span>{r.name}</figcaption></figure>)}</div>
  </div></section>;
}

const promos = [
  { kicker: 'Fresh daily', title: 'Warm manakeesh', image: photos.oven },
  { kicker: 'Most loved', title: 'Shawarma wrap', image: photos.wrap },
  { kicker: 'Straight off the grill', title: 'Kabab & tawook', image: photos.grill },
];

export function PromoTrio() {
  return <section className="section promo-trio" aria-label="Featured dishes"><div className="site-width promo-grid">
    {promos.map(p => <article className="promo-card" key={p.title}><img src={p.image} alt={p.title} loading="lazy"/><div className="promo-copy"><span>{p.kicker}</span><h3>{p.title}</h3><Button asChild size="sm"><Link to="/menu">See menu<ArrowRight/></Link></Button></div></article>)}
  </div></section>;
}
