import wrap from '@/assets/wrap.jpg.asset.json';
import plate from '@/assets/plate.jpg.asset.json';
import family from '@/assets/family.png.asset.json';
import grill from '@/assets/grill.jpg.asset.json';
import falafel from '@/assets/falafel.png.asset.json';
import rox from '@/assets/rox.jpg.asset.json';
import shawarma from '@/assets/shawarma.jpg.asset.json';
import oven from '@/assets/oven.jpg.asset.json';

export const restaurant = {
  order: 'https://order.online/business/-14663353?pickup=true',
  phone: 'tel:+15197411110',
  directions: 'https://www.google.com/maps/dir/?api=1&destination=Zay+Zaman+Restaurant+309+Lancaster+St+W+Kitchener+ON+N2H+4V4',
  review: 'https://www.google.com/maps/search/?api=1&query=Zay+Zaman+Restaurant+309+Lancaster+St+W+Kitchener',
};
export const photos = { wrap: wrap.url, plate: plate.url, family: family.url, grill: grill.url, falafel: falafel.url, rox: rox.url, shawarma: shawarma.url, oven: oven.url };
export type MenuItem = { name: string; price: number; description: string; category: string; image?: string; badge?: string };
export const favourites: MenuItem[] = [
  { name: 'Shawarma Wrap', price: 13.49, description: 'Chicken or beef, fresh toppings and garlic sauce, wrapped in warm saj or pita.', category: 'Wraps', image: photos.wrap, badge: 'Most loved' },
  { name: 'Shawarma Plate', price: 19.99, description: 'Your favourite shawarma with a choice of rice, fries or fresh salad.', category: 'Plates', image: photos.plate },
  { name: 'Shawarma Family Plate', price: 76.99, description: 'Four shawarma wraps, crispy fries, garlic sauce and pickles. Made to share.', category: 'Family plates', image: photos.family, badge: 'Made for sharing' },
  { name: 'Falafel Family Plate', price: 68.99, description: 'Four falafel wraps with fries, fresh vegetables and your choice of sauces.', category: 'Family plates', image: photos.falafel, badge: 'Vegetarian' },
  { name: 'Grill Family Plate', price: 75, description: 'Eight kabab and tawook skewers with rice or fries, pickles and garlic sauce.', category: 'Family plates', image: photos.grill },
  { name: 'On The Rox', price: 16.25, description: 'Freshly shaved shawarma over seasoned rice or crispy golden fries.', category: 'Plates', image: photos.rox },
];
export const menuItems: MenuItem[] = [...favourites,
  ...[
    ['Shawarma Zay Zaman',21.49,'Plates'],['Grill Plate',22.49,'Plates'],['Falafel Plate',19.99,'Plates'],['Burger Plate',12.49,'Plates'],
    ['Falafel Wrap',13.49,'Wraps'],['Tawook Wrap',16.99,'Wraps'],['Kabab Wrap',16.99,'Wraps'],
    ['Shawarma Pizza · 14″',24.99,'Pizza & manakeesh'],['Cheese Pizza · 14″',16.99,'Pizza & manakeesh'],['Halal Pepperoni Pizza · 14″',21.99,'Pizza & manakeesh'],
    ['Za’atar Manakeesh · 8″',7,'Pizza & manakeesh'],['Cheese Manakeesh · 8″',8.99,'Pizza & manakeesh'],['Beef Manakeesh · 8″',8.99,'Pizza & manakeesh'],['Muhammara Manakeesh · 8″',7.99,'Pizza & manakeesh'],
    ['Sambousa',2.99,'Sides & drinks'],['Hummus',7.99,'Sides & drinks'],['Falafel · 6 pieces',6.5,'Sides & drinks'],['Fries',6.5,'Sides & drinks'],['Rice',6.5,'Sides & drinks'],['Shawarma Poutine',17.99,'Plates'],['Kapsalon',17.99,'Plates'],
    ['Canned drink',1.99,'Sides & drinks'],['Water',1.99,'Sides & drinks'],['Ayran',3.99,'Sides & drinks'],['Barbican',3.99,'Sides & drinks'],['Juice',3.99,'Sides & drinks'],['Red Bull',4.99,'Sides & drinks'],
  ].map(([name,price,category]) => ({ name: String(name), price: Number(price), category: String(category), description: '' })),
];
export const categories = ['All', 'Wraps', 'Plates', 'Family plates', 'Pizza & manakeesh', 'Sides & drinks'];
export function filterMenu(category: string, query: string) { return menuItems.filter(item => (category === 'All' || item.category === category) && `${item.name} ${item.description}`.toLowerCase().includes(query.trim().toLowerCase())); }
export const priceLabel = (price: number) => `$${price.toFixed(2)}`;
export function pageHead(title: string, description: string) { return { meta: [{ title: `${title} — Zay Zaman Restaurant` }, { name: 'description', content: description }, { property: 'og:title', content: `${title} — Zay Zaman Restaurant` }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] }; }